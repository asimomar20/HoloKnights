import cv2
import mediapipe as mp
from ultralytics import YOLO
import numpy as np
import os

# تحميل النموذج
model = YOLO("yolov8n.pt")
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False)

# إعدادات التصغير
resize_scale = 0.5  # للتحكم في حجم العرض (0.5 = نصف الحجم الأصلي)

# دالة لحساب المسافة بين نقطتين
def euclidean(p1, p2):
    return np.linalg.norm(np.array(p1) - np.array(p2))

# تحليل الفيديو
def analyze_video(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"❌ Failed to open video: {video_path}")
        return

    previous_y = None
    direction = None
    min_height_diff = 5
    juggles = 0
    current_attempt_juggles = 0
    attempts = 0
    all_attempts = []

    right_count = 0
    left_count = 0
    max_y_threshold = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if max_y_threshold is None:
            h, w, _ = frame.shape
            max_y_threshold = int(h * 0.88)

        results = model(frame)[0]
        ball_center = None
        for result in results.boxes.data:
            cls_id = int(result[5])
            if model.names[cls_id] == "sports ball":
                x1, y1, x2, y2 = map(int, result[:4])
                cx = int((x1 + x2) / 2)
                cy = int((y1 + y2) / 2)
                ball_center = (cx, cy)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 255), 2)
                cv2.putText(frame, "Ball", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
                break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results_pose = pose.process(frame_rgb)
        right_foot = None
        left_foot = None
        if results_pose.pose_landmarks:
            h, w, _ = frame.shape
            landmarks = results_pose.pose_landmarks.landmark
            right = landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX]
            left = landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX]
            right_foot = (int(right.x * w), int(right.y * h))
            left_foot = (int(left.x * w), int(left.y * h))

            cv2.circle(frame, right_foot, 6, (0, 0, 255), -1)
            cv2.putText(frame, "Right", (right_foot[0]+5, right_foot[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            cv2.circle(frame, left_foot, 6, (0, 255, 0), -1)
            cv2.putText(frame, "Left", (left_foot[0]+5, left_foot[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        if ball_center:
            cy = ball_center[1]

            if previous_y is not None:
                delta = cy - previous_y

                if delta > min_height_diff:
                    if direction == 'up':
                        juggles += 1
                        current_attempt_juggles += 1

                        if right_foot and left_foot:
                            dist_right = euclidean(ball_center, right_foot)
                            dist_left = euclidean(ball_center, left_foot)
                            if dist_right < dist_left:
                                right_count += 1
                            else:
                                left_count += 1
                    direction = 'down'
                elif delta < -min_height_diff:
                    direction = 'up'

                if cy > max_y_threshold:
                    if current_attempt_juggles > 0:
                        attempts += 1
                        all_attempts.append(current_attempt_juggles)
                        current_attempt_juggles = 0

            previous_y = cy

        # عرض النتائج على الشاشة (بتكبير الخط)
        x_offset = 30
        y_offset = 50
        spacing = 45  # ← زيادة المسافة بين السطور
        font_scale = 1.2  # ← حجم الخط
        font_thickness = 3  # ← سمك الخط

        cv2.putText(frame, f"Juggles: {juggles}", (x_offset, y_offset), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255,255,255), font_thickness)
        cv2.putText(frame, f"Attempts: {attempts}", (x_offset, y_offset + spacing), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255,255,255), font_thickness)
        cv2.putText(frame, f"Right Foot: {right_count}", (x_offset, y_offset + 2*spacing), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (0,0,255), font_thickness)
        cv2.putText(frame, f"Left Foot: {left_count}", (x_offset, y_offset + 3*spacing), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (0,255,0), font_thickness)


        # تصغير الفريم قبل العرض
        frame_resized = cv2.resize(frame, (0, 0), fx=resize_scale, fy=resize_scale)
        cv2.imshow("Juggle Analyzer", frame_resized)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    if current_attempt_juggles > 0:
        attempts += 1
        all_attempts.append(current_attempt_juggles)

    print(f"\n📹 Video: {os.path.basename(video_path)}")
    print(f"Total juggles: {juggles}")
    print(f"Total attempts: {attempts}")
    if attempts > 0:
        accuracy = sum(all_attempts) / attempts
        print(f"Average juggles per attempt (Accuracy): {accuracy:.2f}")
        print(f"Best attempt: {max(all_attempts)} juggles")
        print(f"Worst attempt: {min(all_attempts)} juggles")
    else:
        print("No valid attempts detected.")

    print(f"Right foot used: {right_count} times")
    print(f"Left foot used: {left_count} times")

    total_foot = right_count + left_count
    if total_foot > 0:
        right_percent = (right_count / total_foot) * 100
        left_percent = (left_count / total_foot) * 100
        print(f"Right foot usage: {right_percent:.2f}%")
        print(f"Left foot usage: {left_percent:.2f}%")

        if right_percent > left_percent:
            print("Preferred foot: Right")
        elif left_percent > right_percent:
            print("Preferred foot: Left")
        else:
            print("Preferred foot: Balanced usage")
    else:
        print("Preferred foot: Not enough data")

# اسم الفيديو
video_name = "sample.mp4"
analyze_video(video_name)

pose.close()
