import cv2
import mediapipe as mp
import numpy as np
import open3d as o3d

# 1. إعداد MediaPipe
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False,
                    model_complexity=2,
                    min_detection_confidence=0.5,
                    min_tracking_confidence=0.5)

# 2. مسار الفيديو
video_path = "sample.mp4"
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    raise RuntimeError(f"Cannot open {video_path}")

# 3. دالة لإنشاء أسطوانة تربط بين نقطتين
def create_cylinder(p0, p1, radius=0.01, color=[0.7,0.7,0.7]):
    vec = p1 - p0
    length = np.linalg.norm(vec)
    cyl = o3d.geometry.TriangleMesh.create_cylinder(radius=radius, height=length)
    cyl.compute_vertex_normals()
    cyl.paint_uniform_color(color)
    # تدوير من محور Z إلى اتجاه vec
    a = np.array([0,0,1])
    b = vec / length
    v = np.cross(a, b)
    c = np.dot(a, b)
    s = np.linalg.norm(v)
    if s > 1e-6:
        kmat = np.array([[0,-v[2],v[1]],
                         [v[2],0,-v[0]],
                         [-v[1],v[0],0]])
        R = np.eye(3) + kmat + (kmat @ kmat) * ((1 - c) / (s**2))
        cyl.rotate(R, center=(0,0,0))
    cyl.translate(p0)
    return cyl

# 4. دالة لإنشاء كرة عند نقطة
def create_sphere(center, radius=0.02, color=[1,0.6,0]):
    sph = o3d.geometry.TriangleMesh.create_sphere(radius=radius)
    sph.compute_vertex_normals()
    sph.paint_uniform_color(color)
    sph.translate(center)
    return sph

# 5. تهيئة نافذة Open3D
vis = o3d.visualization.Visualizer()
vis.create_window(window_name="Player 3D Pose with Spheres", width=800, height=600)
opt = vis.get_render_option()
opt.background_color = np.array([1,1,1])

connections = list(mp_pose.POSE_CONNECTIONS)
first_frame = True
cylinders = []    # أسطوانات العظام
spheres = []      # كرات المفاصل

while True:
    ret, frame = cap.read()
    if not ret:
        break

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = pose.process(rgb)
    if not res.pose_world_landmarks:
        continue

    lm = res.pose_world_landmarks.landmark
    coords = np.array([[p.x, p.y, p.z] for p in lm], dtype=np.float64)

    if first_frame:
        # لأول مرة: ننشئ كل الأسطوانات والكرات
        for start, end in connections:
            cyl = create_cylinder(coords[start], coords[end], radius=0.008)
            cylinders.append(cyl)
            vis.add_geometry(cyl)
        for idx in range(len(coords)):
            sph = create_sphere(coords[idx], radius=0.02, color=[1,0.6,0])
            spheres.append(sph)
            vis.add_geometry(sph)
        first_frame = False
    else:
        # تحديث الأسطوانات
        for cyl, (start, end) in zip(cylinders, connections):
            new_cyl = create_cylinder(coords[start], coords[end], radius=0.008)
            cyl.vertices = new_cyl.vertices
            cyl.triangles = new_cyl.triangles
            cyl.compute_vertex_normals()
            vis.update_geometry(cyl)
        # تحديث الكرات
        for sph, center in zip(spheres, coords):
            new_sph = create_sphere(center, radius=0.02)
            sph.vertices = new_sph.vertices
            sph.triangles = new_sph.triangles
            sph.compute_vertex_normals()
            vis.update_geometry(sph)

    vis.poll_events()
    vis.update_renderer()

cap.release()
pose.close()
vis.destroy_window()
