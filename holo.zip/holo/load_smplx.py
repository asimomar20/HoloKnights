import os
import torch
from smplx import SMPLX

# 1) مسار مجلد النماذج
model_folder = os.path.join("models", "smplx_v1_1")

# 2) اختر الجندر 'neutral' أو 'male' أو 'female'
gender = 'neutral'

# 3) اختيار الجهاز (GPU لو متوفر، وإلا CPU)
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

# 4) تحميل نموذج SMPL‑X بكامل الجسم (مع اليدين والتعابير)
smplx_model = SMPLX(
    model_path=model_folder,
    model_type='smplx',
    gender=gender,
    ext='npz',
    create_global_orient=True,
    create_body_pose=True,
    create_betas=True,
    create_left_hand_pose=True,    # تفعيل حركة اليد اليسرى
    create_right_hand_pose=True,   # تفعيل حركة اليد اليمنى
    create_expression=True,        # تفعيل تعابير الوجه
).to(device)

# 5) اختبار سريع: استخراج T‑pose mesh
output = smplx_model()
vertices = output.vertices.detach().cpu().numpy()[0]
print("Loaded SMPL-X model. Number of vertices:", vertices.shape[0])

