import os
import torch
import numpy as np
from smplx import SMPLX

# 1) تحميل الـ landmarks الثلاثية الأبعاد
landmarks_all = np.load("landmarks3d.npy")  # شكلها (F, 33, 3)
num_frames    = landmarks_all.shape[0]
print(f"Loaded landmarks for {num_frames} frames.")

# 2) تحميل نموذج SMPL-X
model_folder = os.path.join("models", "smplx_v1_1")
device       = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
smplx_model  = SMPLX(
    model_path=model_folder,
    model_type='smplx',
    gender='neutral',
    ext='npz',
    create_global_orient=True,
    create_body_pose=True,
    create_betas=True,
).to(device)
smplx_model.eval()

# نحتفظ بالـ faces و joint regressor خارج الحلقة
faces       = smplx_model.faces                  # (F,3)
J_regressor = torch.tensor(
    smplx_model.J_regressor,
    dtype=torch.float32,
    device=device
)  # شكلها (J, V)

# 3) حلقة عبر كل فريم
for frame_idx in range(num_frames):
    lm = landmarks_all[frame_idx]
    # إذا الـ landmarks كلها NaN نتخطاه
    if np.isnan(lm).all():
        print(f"Frame {frame_idx}: no landmarks detected, skipped.")
        continue

    # 4) إعادة تهيئة المتغيرات والقابلة للتعلّم لكل فريم
    global_orient = torch.zeros((1, 3),  requires_grad=True, device=device)
    body_pose     = torch.zeros((1, 63), requires_grad=True, device=device)
    betas         = torch.zeros((1, 10), requires_grad=True, device=device)

    optimizer = torch.optim.LBFGS(
        [global_orient, body_pose, betas],
        lr=1e-2,
        max_iter=20,
        line_search_fn="strong_wolfe"
    )

    target = torch.from_numpy(lm).unsqueeze(0).to(device)  # (1, 33, 3)

    # 5) دالة الخسارة (closure) المستخدمة بالـ LBFGS
    def closure():
        optimizer.zero_grad()
        out = smplx_model(
            global_orient=global_orient,
            body_pose=body_pose,
            betas=betas
        )
        verts = out.vertices  # (1, V, 3)
        # نتوقع joints من الـ vertices باستخدام J_regressor
        pred_joints = torch.einsum('ji,bvk->bjk', J_regressor, verts)  # (1,J,3)
        pred = pred_joints[:, :target.shape[1], :]
        loss = torch.mean((pred - target)**2)
        loss.backward()
        return loss

    print(f"=== Fitting frame {frame_idx} ===")
    optimizer.step(closure)
    print("Fitting done.")

    # 6) استخراج الميش النهائي للفريم
    with torch.no_grad():
        fitted = smplx_model(
            global_orient=global_orient,
            body_pose=body_pose,
            betas=betas
        )
    verts_final = fitted.vertices[0].cpu().numpy()  # (V,3)

    # 7) تصدير OBJ داخل الحلقة عشان يصدر لكل فريم
    out_obj = f"fitted_frame_{frame_idx}.obj"
    with open(out_obj, 'w') as f:
        # هذا السطر يضمن اسم object فريد داخل كل ملف OBJ
        f.write(f"o fitted_frame_{frame_idx}\n")

        # رؤوس الـ vertices
        for v in verts_final:
            f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")

        # وجوه الـ mesh (1-based indexing)
        for face in faces:
            f.write(f"f {face[0]+1} {face[1]+1} {face[2]+1}\n")

    print(f"Saved {out_obj}\n")

print("All frames processed.")
