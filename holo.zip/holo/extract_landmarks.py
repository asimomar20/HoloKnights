import cv2
import mediapipe as mp
import numpy as np

# 1. إعداد MediaPipe Pose لاستخراج world landmarks
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(
    static_image_mode=False,
    model_complexity=2,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# 2. افتح الفيديو
video_path = "sample.mp4"
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    raise RuntimeError(f"Cannot open {video_path}")

landmarks_all = []  # لتخزين الإحداثيات لكل فريم

# 3. حلقة عبر كل الإطارات
frame_idx = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # نحول BGR → RGB
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = pose.process(rgb)

    if res.pose_world_landmarks:
        lm = res.pose_world_landmarks.landmark
        coords = np.array([[p.x, p.y, p.z] for p in lm], dtype=np.float32)
    else:
        # لو لم يكتشف الجسم، نعوّض بــ NaN
        coords = np.full((33, 3), np.nan, dtype=np.float32)

    landmarks_all.append(coords)
    frame_idx += 1

cap.release()
pose.close()

# 4. تحويل القائمة إلى مصفوفة وحفظها
landmarks_array = np.stack(landmarks_all, axis=0)  # شكلها (F, 33, 3)
np.save("landmarks3d.npy", landmarks_array)
print(f"Done! Extracted {landmarks_array.shape[0]} frames, saved to landmarks3d.npy")
